#tag WebContainerControl
Begin wc_base wc_CaseDetails
   Compatibility   =   ""
   ControlCount    =   0
   ControlID       =   ""
   CSSClasses      =   ""
   Enabled         =   True
   Height          =   761
   Indicator       =   0
   LayoutDirection =   0
   LayoutType      =   0
   Left            =   0
   LockBottom      =   False
   LockHorizontal  =   False
   LockLeft        =   True
   LockRight       =   False
   LockTop         =   True
   LockVertical    =   False
   PanelIndex      =   0
   ScrollDirection =   0
   TabIndex        =   0
   Top             =   0
   Visible         =   True
   Width           =   1084
   _mDesignHeight  =   0
   _mDesignWidth   =   0
   _mPanelIndex    =   -1
   Begin WebListBox lstVideos
      AllowRowReordering=   False
      ColumnCount     =   3
      ColumnWidths    =   ""
      ControlID       =   ""
      CSSClasses      =   ""
      DefaultRowHeight=   49
      Enabled         =   True
      GridLineStyle   =   3
      HasBorder       =   True
      HasHeader       =   True
      HeaderHeight    =   0
      Height          =   388
      HighlightSortedColumn=   True
      Index           =   -2147483648
      Indicator       =   0
      InitialValue    =   "File	View	Order"
      LastAddedRowIndex=   0
      LastColumnIndex =   0
      LastRowIndex    =   0
      Left            =   0
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   True
      LockVertical    =   False
      NoRowsMessage   =   ""
      PanelIndex      =   0
      ProcessingMessage=   ""
      RowCount        =   0
      RowSelectionType=   1
      Scope           =   0
      SearchCriteria  =   ""
      SelectedRowColor=   &c0d6efd
      SelectedRowIndex=   0
      TabIndex        =   25
      TabStop         =   True
      Tooltip         =   ""
      Top             =   105
      Visible         =   True
      Width           =   542
      _mPanelIndex    =   -1
   End
   Begin WebLabel lblCaseInfo
      Bold            =   True
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FontName        =   ""
      FontSize        =   24.0
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Italic          =   False
      Left            =   0
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   True
      LockVertical    =   False
      Multiline       =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   0
      TabStop         =   True
      Text            =   "Case Information"
      TextAlignment   =   0
      TextColor       =   &c0087FE00
      Tooltip         =   ""
      Top             =   0
      Underline       =   False
      Visible         =   True
      Width           =   477
      _mPanelIndex    =   -1
   End
   Begin WebTextField txtSerialNumber
      AllowAutoComplete=   False
      AllowSpellChecking=   False
      Caption         =   ""
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FieldType       =   0
      Height          =   38
      Hint            =   ""
      Index           =   -2147483648
      Indicator       =   0
      Left            =   578
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      MaximumCharactersAllowed=   0
      PanelIndex      =   0
      ReadOnly        =   True
      Scope           =   0
      TabIndex        =   7
      TabStop         =   True
      Text            =   ""
      TextAlignment   =   0
      Tooltip         =   ""
      Top             =   105
      Visible         =   True
      Width           =   240
      _mPanelIndex    =   -1
   End
   Begin WebLabel lblLabel
      Bold            =   False
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FontName        =   ""
      FontSize        =   0.0
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Italic          =   False
      Left            =   578
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      Multiline       =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   8
      TabStop         =   True
      Text            =   "Desciption"
      TextAlignment   =   0
      TextColor       =   &c000000FF
      Tooltip         =   ""
      Top             =   151
      Underline       =   False
      Visible         =   True
      Width           =   90
      _mPanelIndex    =   -1
   End
   Begin WebTextField txtCaseLabel
      AllowAutoComplete=   False
      AllowSpellChecking=   False
      Caption         =   ""
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FieldType       =   0
      Height          =   38
      Hint            =   ""
      Index           =   -2147483648
      Indicator       =   0
      Left            =   578
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      MaximumCharactersAllowed=   0
      PanelIndex      =   0
      ReadOnly        =   False
      Scope           =   0
      TabIndex        =   9
      TabStop         =   True
      Text            =   ""
      TextAlignment   =   0
      Tooltip         =   ""
      Top             =   190
      Visible         =   True
      Width           =   240
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkPericardialEffusion
      Caption         =   "Significant Effusion"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   32
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   394
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   21
      TabStop         =   True
      Tooltip         =   ""
      Top             =   660
      Value           =   False
      Visible         =   True
      Width           =   167
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkIVCHighPressure
      Caption         =   "IVC - High RA Pressure"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   35
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   394
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   22
      TabStop         =   True
      Tooltip         =   ""
      Top             =   694
      Value           =   False
      Visible         =   True
      Width           =   200
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkRequiresFullEcho
      Caption         =   "Requires full ECHO?"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   34
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   0
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   23
      TabStop         =   True
      Tooltip         =   ""
      Top             =   727
      Value           =   False
      Visible         =   True
      Width           =   212
      _mPanelIndex    =   -1
   End
   Begin WebTextArea txtCorrectConclusions
      AllowReturnKey  =   True
      AllowSpellChecking=   False
      Caption         =   ""
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   32
      Hint            =   "Correct conclusions"
      Index           =   -2147483648
      Indicator       =   0
      Left            =   222
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   True
      LockTop         =   False
      LockVertical    =   False
      MaximumCharactersAllowed=   0
      PanelIndex      =   0
      ReadOnly        =   False
      Scope           =   0
      TabIndex        =   24
      TabStop         =   True
      Text            =   ""
      TextAlignment   =   0
      Tooltip         =   ""
      Top             =   727
      Visible         =   True
      Width           =   432
      _mPanelIndex    =   -1
   End
   Begin WebLabel lblVideosTitle
      Bold            =   True
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FontName        =   ""
      FontSize        =   0.0
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Italic          =   False
      Left            =   0
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   True
      LockVertical    =   False
      Multiline       =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   26
      TabStop         =   True
      Text            =   "Case Videos"
      TextAlignment   =   0
      TextColor       =   &c000000FF
      Tooltip         =   ""
      Top             =   66
      Underline       =   False
      Visible         =   True
      Width           =   199
      _mPanelIndex    =   -1
   End
   Begin WebLabel lblVideoPreview
      Bold            =   True
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FontName        =   ""
      FontSize        =   0.0
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Italic          =   False
      Left            =   578
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      Multiline       =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   27
      TabStop         =   True
      Text            =   "Video Preview"
      TextAlignment   =   0
      TextColor       =   &c000000FF
      Tooltip         =   ""
      Top             =   287
      Underline       =   False
      Visible         =   True
      Width           =   122
      _mPanelIndex    =   -1
   End
   Begin WebButton btnStartUpload
      AllowAutoDisable=   False
      Cancel          =   False
      Caption         =   "Upload"
      ControlID       =   ""
      CSSClasses      =   ""
      Default         =   False
      Enabled         =   False
      Height          =   41
      Index           =   -2147483648
      Indicator       =   0
      Left            =   222
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      Outlined        =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   33
      TabStop         =   True
      Tooltip         =   ""
      Top             =   501
      Visible         =   True
      Width           =   90
      _mPanelIndex    =   -1
   End
   Begin WebButton btnDeleteVideo
      AllowAutoDisable=   False
      Cancel          =   False
      Caption         =   "Delete"
      ControlID       =   ""
      CSSClasses      =   ""
      Default         =   False
      Enabled         =   True
      Height          =   41
      Index           =   -2147483648
      Indicator       =   0
      Left            =   452
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      Outlined        =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   34
      TabStop         =   True
      Tooltip         =   ""
      Top             =   501
      Visible         =   True
      Width           =   90
      _mPanelIndex    =   -1
   End
   Begin WebButton btnSaveAll
      AllowAutoDisable=   False
      Cancel          =   False
      Caption         =   "Save"
      ControlID       =   ""
      CSSClasses      =   ""
      Default         =   False
      Enabled         =   True
      Height          =   38
      Index           =   -2147483648
      Indicator       =   1
      Left            =   966
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   False
      LockVertical    =   False
      Outlined        =   False
      PanelIndex      =   0
      Scope           =   2
      TabIndex        =   36
      TabStop         =   True
      Tooltip         =   ""
      Top             =   723
      Visible         =   True
      Width           =   118
      _mPanelIndex    =   -1
   End
   Begin WebButton btnCancelChanges
      AllowAutoDisable=   False
      Cancel          =   False
      Caption         =   "Cancel"
      ControlID       =   ""
      CSSClasses      =   ""
      Default         =   False
      Enabled         =   True
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Left            =   858
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   False
      LockVertical    =   False
      Outlined        =   False
      PanelIndex      =   0
      Scope           =   2
      TabIndex        =   37
      TabStop         =   True
      Tooltip         =   ""
      Top             =   723
      Visible         =   True
      Width           =   100
      _mPanelIndex    =   -1
   End
   Begin WebFileUploader uplVideo
      Caption         =   "Select video"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Filter          =   "video/mp4,video/*"
      HasFileNameField=   True
      Height          =   41
      Hint            =   ""
      Index           =   -2147483648
      Indicator       =   ""
      Left            =   0
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      MaximumBytes    =   0
      MaximumFileCount=   1
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   40
      TabStop         =   True
      Tooltip         =   ""
      Top             =   501
      UploadTimeout   =   0
      Visible         =   True
      Width           =   220
      _mPanelIndex    =   -1
   End
   Begin WebLabel lblGroupAssignment
      Bold            =   False
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FontName        =   ""
      FontSize        =   0.0
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Italic          =   False
      Left            =   842
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      Multiline       =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   41
      TabStop         =   True
      Text            =   "Groups"
      TextAlignment   =   0
      TextColor       =   &c000000FF
      Tooltip         =   ""
      Top             =   66
      Underline       =   False
      Visible         =   True
      Width           =   64
      _mPanelIndex    =   -1
   End
   Begin WebPopupMenu popAvailableGroups
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      InitialValue    =   ""
      LastAddedRowIndex=   0
      LastRowIndex    =   0
      Left            =   842
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      PanelIndex      =   0
      RowCount        =   0
      Scope           =   0
      SelectedRowIndex=   0
      SelectedRowText =   ""
      TabIndex        =   43
      TabStop         =   True
      Tooltip         =   ""
      Top             =   188
      Visible         =   True
      Width           =   240
      _mPanelIndex    =   -1
   End
   Begin WebButton btnAddGroup
      AllowAutoDisable=   False
      Cancel          =   False
      Caption         =   "Add Group"
      ControlID       =   ""
      CSSClasses      =   ""
      Default         =   False
      Enabled         =   True
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Left            =   842
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      Outlined        =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   44
      TabStop         =   True
      Tooltip         =   ""
      Top             =   234
      Visible         =   True
      Width           =   109
      _mPanelIndex    =   -1
   End
   Begin WebListBox lstAssignedGroups
      AllowRowReordering=   False
      ColumnCount     =   1
      ColumnWidths    =   ""
      ControlID       =   ""
      CSSClasses      =   ""
      DefaultRowHeight=   24
      Enabled         =   True
      GridLineStyle   =   1
      HasBorder       =   True
      HasHeader       =   False
      HeaderHeight    =   0
      Height          =   72
      HighlightSortedColumn=   True
      Index           =   -2147483648
      Indicator       =   0
      InitialValue    =   ""
      LastAddedRowIndex=   0
      LastColumnIndex =   0
      LastRowIndex    =   0
      Left            =   842
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      NoRowsMessage   =   ""
      PanelIndex      =   0
      ProcessingMessage=   ""
      RowCount        =   0
      RowSelectionType=   1
      Scope           =   0
      SearchCriteria  =   ""
      SelectedRowColor=   &c0d6efd
      SelectedRowIndex=   0
      TabIndex        =   46
      TabStop         =   True
      Tooltip         =   ""
      Top             =   103
      Visible         =   True
      Width           =   240
      _mPanelIndex    =   -1
   End
   Begin WebButton btnRemoveGroup
      AllowAutoDisable=   False
      Cancel          =   False
      Caption         =   "Remove"
      ControlID       =   ""
      CSSClasses      =   ""
      Default         =   False
      Enabled         =   True
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Left            =   973
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      Outlined        =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   47
      TabStop         =   True
      Tooltip         =   ""
      Top             =   234
      Visible         =   True
      Width           =   109
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkLVSizeDilated
      Caption         =   "LV significantly dilated"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   34
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   0
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   11
      TabStop         =   True
      Tooltip         =   ""
      Top             =   592
      Value           =   False
      Visible         =   True
      Width           =   212
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkLVFunctionImpaired
      Caption         =   "LV significantly Impaired"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   34
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   0
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   12
      TabStop         =   True
      Tooltip         =   ""
      Top             =   626
      Value           =   False
      Visible         =   True
      Width           =   212
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkRVSizeDilated
      Caption         =   "RV significantly dilated"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   34
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   0
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   13
      TabStop         =   True
      Tooltip         =   ""
      Top             =   660
      Value           =   False
      Visible         =   True
      Width           =   212
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkRVFunctionImpaired
      Caption         =   "RV significantly Impaired"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   34
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   0
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   14
      TabStop         =   True
      Tooltip         =   ""
      Top             =   694
      Value           =   False
      Visible         =   True
      Width           =   212
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkAorticStenosis
      Caption         =   "Significant AS"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   34
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   230
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   15
      TabStop         =   True
      Tooltip         =   ""
      Top             =   592
      Value           =   False
      Visible         =   True
      Width           =   161
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkAorticRegurgitation
      Caption         =   "Significant AR"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   32
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   230
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   16
      TabStop         =   True
      Tooltip         =   ""
      Top             =   628
      Value           =   False
      Visible         =   True
      Width           =   161
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkMitralStenosis
      Caption         =   "Significant MS"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   32
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   230
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   17
      TabStop         =   True
      Tooltip         =   ""
      Top             =   662
      Value           =   False
      Visible         =   True
      Width           =   161
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkMitralRegurgitation
      Caption         =   "Significant MR"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   32
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   230
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   18
      TabStop         =   True
      Tooltip         =   ""
      Top             =   696
      Value           =   False
      Visible         =   True
      Width           =   161
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkTricuspidStenosis
      Caption         =   "Significant TS"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   32
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   394
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   19
      TabStop         =   True
      Tooltip         =   ""
      Top             =   592
      Value           =   False
      Visible         =   True
      Width           =   148
      _mPanelIndex    =   -1
   End
   Begin WebCheckbox chkTricuspidRegurgitation
      Caption         =   "Significant TR"
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   32
      Indeterminate   =   True
      Index           =   -2147483648
      Indicator       =   0
      Left            =   394
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   20
      TabStop         =   True
      Tooltip         =   ""
      Top             =   626
      Value           =   False
      Visible         =   True
      Width           =   148
      _mPanelIndex    =   -1
   End
   Begin WebButton btnUndoVideoEdit
      AllowAutoDisable=   False
      Cancel          =   False
      Caption         =   "Undo edit"
      ControlID       =   ""
      CSSClasses      =   ""
      Default         =   False
      Enabled         =   False
      Height          =   41
      Index           =   -2147483648
      Indicator       =   0
      Left            =   320
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      Outlined        =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   39
      TabStop         =   True
      Tooltip         =   ""
      Top             =   501
      Visible         =   True
      Width           =   112
      _mPanelIndex    =   -1
   End
   Begin WebLabel lblVideoPreview1
      Bold            =   True
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FontName        =   ""
      FontSize        =   0.0
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Italic          =   False
      Left            =   0
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   False
      LockTop         =   False
      LockVertical    =   False
      Multiline       =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   48
      TabStop         =   True
      Text            =   "Correct Answers"
      TextAlignment   =   0
      TextColor       =   &c000000FF
      Tooltip         =   ""
      Top             =   560
      Underline       =   False
      Visible         =   True
      Width           =   167
      _mPanelIndex    =   -1
   End
   Begin WebLabel lblVideosTitle1
      Bold            =   True
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      FontName        =   ""
      FontSize        =   0.0
      Height          =   38
      Index           =   -2147483648
      Indicator       =   0
      Italic          =   False
      Left            =   578
      LockBottom      =   False
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   False
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      Multiline       =   False
      PanelIndex      =   0
      Scope           =   0
      TabIndex        =   49
      TabStop         =   True
      Text            =   "Case Details"
      TextAlignment   =   0
      TextColor       =   &c000000FF
      Tooltip         =   ""
      Top             =   66
      Underline       =   False
      Visible         =   True
      Width           =   199
      _mPanelIndex    =   -1
   End
   Begin WebHTMLViewer htmlVideoPreview
      ControlID       =   ""
      CSSClasses      =   ""
      Enabled         =   True
      Height          =   373
      Index           =   -2147483648
      Indicator       =   ""
      Left            =   587
      LockBottom      =   True
      LockedInPosition=   False
      LockHorizontal  =   False
      LockLeft        =   True
      LockRight       =   True
      LockTop         =   True
      LockVertical    =   False
      PanelIndex      =   0
      Scope           =   2
      TabIndex        =   50
      TabStop         =   True
      Tooltip         =   ""
      Top             =   319
      UseSandbox      =   False
      Visible         =   True
      Width           =   495
      _mPanelIndex    =   -1
   End
End
#tag EndWebContainerControl

#tag WindowCode
	#tag Event
		Sub Opening()
		  ' ******************************************************************
		  ' wc_CaseDetails.Opening Event
		  ' ******************************************************************
		  ' Configure listbox columns (3 columns: Filename, View Description, Order)
		  ' Note: Column spacing is large in WebListBox, so widths need to be generous
		  
		  
		  ' Set editable columns
		  lstVideos.ColumnTypeAt(1) = WebListBox.CellTypes.TextField
		  lstVideos.ColumnTypeAt(2) = WebListBox.CellTypes.TextField
		  
		  LoadAvailableGroups
		  LoadCaseDetails
		  LoadCaseVideos
		  mCaseInfoChanged = False
		  mAnswersChanged = False
		  mGroupsChanged = False
		  btnUndoVideoEdit.Enabled = False
		  btnStartUpload.Enabled = False
		  
		  Self.EnableBackButton = True
		  Self.EnableLogoutButton = True
		  UpdateNavigation ' update status of back/login buttons & logged in user
		End Sub
	#tag EndEvent


	#tag Method, Flags = &h0
		Sub ClearCaseFields()
		  ' *******************************************************************************
		  ' ClearCaseFields Method
		  ' *******************************************************************************
		  txtSerialNumber.Text = ""
		  txtCaseLabel.Text = ""
		  chkLVSizeDilated.Value = False
		  chkLVFunctionImpaired.Value = False
		  chkRVSizeDilated.Value = False
		  chkRVFunctionImpaired.Value = False
		  chkAorticStenosis.Value = False
		  chkAorticRegurgitation.Value = False
		  chkMitralStenosis.Value = False
		  chkMitralRegurgitation.Value = False
		  chkTricuspidStenosis.Value = False
		  chkTricuspidRegurgitation.Value = False
		  chkPericardialEffusion.Value = False
		  chkIVCHighPressure.Value = False
		  txtCorrectConclusions.Text = ""
		  chkRequiresFullEcho.Value = False
		End Sub
	#tag EndMethod

	#tag Method, Flags = &h0
		Function GetCurrentGroups() As String
		  ' ******************************************************************
		  ' GetCurrentGroups Method
		  '   Returns: String
		  ' ******************************************************************
		  Var groups() As String
		  
		  For i As Integer = 0 To lstAssignedGroups.RowCount - 1
		    groups.Add(lstAssignedGroups.CellTextAt(i, 0))
		  Next
		  
		  Return String.FromArray(groups, ",")
		End Function
	#tag EndMethod

	#tag Method, Flags = &h21
		Private Sub HandleDeleteVideoConfirm(dialog As WebMessageDialog, button As WebMessageDialogButton)
		  ' ******************************************************************
		  ' HandleDeleteVideoConfirm Method
		  ' ******************************************************************
		  Select Case button
		  Case dialog.ActionButton
		    Var videoID As Integer = lstVideos.RowTagAt(lstVideos.SelectedRowIndex)
		    Var sql As String = "DELETE FROM case_videos WHERE video_id = ?"
		    
		    Try
		      Var ps As MySQLPreparedStatement = Session.DB.Prepare(sql)
		      ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		      ps.Bind(0, videoID)
		      
		      ps.ExecuteSQL
		      
		      MessageBox("Video deleted successfully!")
		      LoadCaseVideos
		      htmlVideoPreview.LoadHTML("")  // Clear the video preview
		      
		    Catch e As DatabaseException
		      MessageBox("Error deleting video: " + e.Message)
		    End Try
		  End Select
		End Sub
	#tag EndMethod

	#tag Method, Flags = &h0
		Sub LoadAssignedGroups(caseGroups As String)
		  ' ******************************************************************
		  ' LoadAssignedGroups Method
		  '   Parameters: caseGroups as String
		  ' ******************************************************************
		  lstAssignedGroups.RemoveAllRows
		  Redim mOriginalGroups(-1)
		  
		  If caseGroups.Trim <> "" Then
		    Var groups() As String = caseGroups.Split(",")
		    For Each group As String In groups
		      Var cleanGroup As String = group.Trim
		      If cleanGroup <> "" Then
		        lstAssignedGroups.AddRow(cleanGroup)
		        mOriginalGroups.Add(cleanGroup)
		      End If
		    Next
		  End If
		End Sub
	#tag EndMethod

	#tag Method, Flags = &h0
		Sub LoadAvailableGroups()
		  ' ******************************************************************
		  ' LoadAvailableGroups Method
		  ' ******************************************************************
		  popAvailableGroups.RemoveAllRows
		  
		  ' Add common groups
		  Var currentYear As Integer = DateTime.Now.Year
		  Var quarters() As String = Array("Q1", "Q2", "Q3", "Q4")
		  Var specialties() As String = Array("Cardiology", "ICU", "ED", "Medicine", "Surgery")
		  
		  For Each specialty As String In specialties
		    For Each quarter As String In quarters
		      popAvailableGroups.AddRow(specialty + " " + Str(currentYear) + " " + quarter)
		    Next
		  Next
		  
		  ' Load existing groups from database (from both user_group and case_groups)
		  Var sql As String = "SELECT DISTINCT user_group FROM users WHERE user_group IS NOT NULL AND user_group <> '' UNION SELECT DISTINCT case_groups FROM cases WHERE case_groups IS NOT NULL AND case_groups <> '' ORDER BY 1"
		  
		  Try
		    Var rs As RowSet = Session.DB.SelectSQL(sql)
		    Var uniqueGroups() As String
		    
		    While Not rs.AfterLastRow
		      Var groupText As String = rs.ColumnAt(0).StringValue
		      
		      ' Split comma-separated groups
		      If groupText.Trim <> "" Then
		        Var groups() As String = groupText.Split(",")
		        For Each group As String In groups
		          Var cleanGroup As String = group.Trim
		          If cleanGroup <> "" Then
		            ' Add if not already in list
		            Var found As Boolean = False
		            For Each existing As String In uniqueGroups
		              If existing = cleanGroup Then
		                found = True
		                Exit For existing
		              End If
		            Next
		            If Not found Then
		              uniqueGroups.Add(cleanGroup)
		            End If
		          End If
		        Next
		      End If
		      
		      rs.MoveToNextRow
		    Wend
		    
		    ' Add unique groups to popup
		    For Each group As String In uniqueGroups
		      ' Check if already in popup
		      Var alreadyExists As Boolean = False
		      For i As Integer = 0 To popAvailableGroups.RowCount - 1
		        If popAvailableGroups.RowTextAt(i) = group Then
		          alreadyExists = True
		          Exit For i
		        End If
		      Next
		      
		      If Not alreadyExists Then
		        popAvailableGroups.AddRow(group)
		      End If
		    Next
		    
		  Catch e As DatabaseException
		    System.DebugLog("Error loading groups: " + e.Message)
		  End Try
		  
		  If popAvailableGroups.RowCount > 0 Then
		    popAvailableGroups.SelectedRowIndex = 0
		  End If
		End Sub
	#tag EndMethod

	#tag Method, Flags = &h0
		Sub LoadCaseDetails()
		  ' ******************************************************************
		  ' LoadCaseDetails Method
		  ' ******************************************************************
		  Var sql As String = "SELECT * FROM cases WHERE case_id = ?"
		  
		  Try
		    Var ps As MySQLPreparedStatement = Session.DB.Prepare(sql)
		    ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		    ps.Bind(0, CaseID)
		    
		    Var rs As RowSet = ps.SelectSQL
		    
		    If rs <> Nil And Not rs.AfterLastRow Then
		      txtSerialNumber.Text = rs.Column("serial_number").StringValue
		      txtCaseLabel.Text = rs.Column("case_label").StringValue
		      
		      ' Load assigned groups
		      Var caseGroups As String = rs.Column("case_groups").StringValue
		      LoadAssignedGroups(caseGroups)
		      
		      ' Load checkbox values (may be NULL/indeterminate)
		      If rs.Column("lv_size_dilated").Value = Nil Then
		        chkLVSizeDilated.Indeterminate = True
		      Else
		        chkLVSizeDilated.Value = rs.Column("lv_size_dilated").BooleanValue
		        chkLVSizeDilated.Indeterminate = False
		      End If
		      
		      If rs.Column("lv_function_impaired").Value = Nil Then
		        chkLVFunctionImpaired.Indeterminate = True
		      Else
		        chkLVFunctionImpaired.Value = rs.Column("lv_function_impaired").BooleanValue
		        chkLVFunctionImpaired.Indeterminate = False
		      End If
		      
		      If rs.Column("rv_size_dilated").Value = Nil Then
		        chkRVSizeDilated.Indeterminate = True
		      Else
		        chkRVSizeDilated.Value = rs.Column("rv_size_dilated").BooleanValue
		        chkRVSizeDilated.Indeterminate = False
		      End If
		      
		      If rs.Column("rv_function_impaired").Value = Nil Then
		        chkRVFunctionImpaired.Indeterminate = True
		      Else
		        chkRVFunctionImpaired.Value = rs.Column("rv_function_impaired").BooleanValue
		        chkRVFunctionImpaired.Indeterminate = False
		      End If
		      
		      If rs.Column("aortic_stenosis_significant").Value = Nil Then
		        chkAorticStenosis.Indeterminate = True
		      Else
		        chkAorticStenosis.Value = rs.Column("aortic_stenosis_significant").BooleanValue
		        chkAorticStenosis.Indeterminate = False
		      End If
		      
		      If rs.Column("aortic_regurgitation_significant").Value = Nil Then
		        chkAorticRegurgitation.Indeterminate = True
		      Else
		        chkAorticRegurgitation.Value = rs.Column("aortic_regurgitation_significant").BooleanValue
		        chkAorticRegurgitation.Indeterminate = False
		      End If
		      
		      If rs.Column("mitral_stenosis_significant").Value = Nil Then
		        chkMitralStenosis.Indeterminate = True
		      Else
		        chkMitralStenosis.Value = rs.Column("mitral_stenosis_significant").BooleanValue
		        chkMitralStenosis.Indeterminate = False
		      End If
		      
		      If rs.Column("mitral_regurgitation_significant").Value = Nil Then
		        chkMitralRegurgitation.Indeterminate = True
		      Else
		        chkMitralRegurgitation.Value = rs.Column("mitral_regurgitation_significant").BooleanValue
		        chkMitralRegurgitation.Indeterminate = False
		      End If
		      
		      If rs.Column("tricuspid_stenosis_significant").Value = Nil Then
		        chkTricuspidStenosis.Indeterminate = True
		      Else
		        chkTricuspidStenosis.Value = rs.Column("tricuspid_stenosis_significant").BooleanValue
		        chkTricuspidStenosis.Indeterminate = False
		      End If
		      
		      If rs.Column("tricuspid_regurgitation_significant").Value = Nil Then
		        chkTricuspidRegurgitation.Indeterminate = True
		      Else
		        chkTricuspidRegurgitation.Value = rs.Column("tricuspid_regurgitation_significant").BooleanValue
		        chkTricuspidRegurgitation.Indeterminate = False
		      End If
		      
		      If rs.Column("pericardial_effusion_significant").Value = Nil Then
		        chkPericardialEffusion.Indeterminate = True
		      Else
		        chkPericardialEffusion.Value = rs.Column("pericardial_effusion_significant").BooleanValue
		        chkPericardialEffusion.Indeterminate = False
		      End If
		      
		      If rs.Column("ivc_high_ra_pressure").Value = Nil Then
		        chkIVCHighPressure.Indeterminate = True
		      Else
		        chkIVCHighPressure.Value = rs.Column("ivc_high_ra_pressure").BooleanValue
		        chkIVCHighPressure.Indeterminate = False
		      End If
		      
		      txtCorrectConclusions.Text = rs.Column("correct_conclusions").StringValue
		      
		      If rs.Column("requires_full_echo").Value = Nil Then
		        chkRequiresFullEcho.Indeterminate = True
		      Else
		        chkRequiresFullEcho.Value = rs.Column("requires_full_echo").BooleanValue
		        chkRequiresFullEcho.Indeterminate = False
		      End If
		    End If
		  Catch e As DatabaseException
		    MessageBox("Error loading case details: " + e.Message)
		  End Try
		End Sub
	#tag EndMethod

	#tag Method, Flags = &h0
		Sub LoadCaseVideos()
		  ' ******************************************************************
		  ' LoadCaseVideos Method
		  ' ******************************************************************
		  lstVideos.RemoveAllRows
		  
		  Var sql As String = "SELECT video_id, video_filename, view_description, video_order FROM case_videos WHERE case_id = ? ORDER BY video_order"
		  
		  Try
		    Var ps As MySQLPreparedStatement = Session.DB.Prepare(sql)
		    ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		    ps.Bind(0, CaseID)
		    
		    Var rs As RowSet = ps.SelectSQL
		    
		    ' Create centered style once (reuse for all rows)
		    Var centeredStyle As New WebStyle
		    centeredStyle.Value("text-align") = "center"
		    
		    While Not rs.AfterLastRow
		      lstVideos.AddRow(rs.Column("video_filename").StringValue)
		      lstVideos.CellTextAt(lstVideos.LastAddedRowIndex, 1) = rs.Column("view_description").StringValue
		      
		      ' Center the order column - use CellValueAt with WebListBoxStyleRenderer
		      Var row As Integer = lstVideos.LastAddedRowIndex
		      Var orderValue As String = Str(rs.Column("video_order").IntegerValue)
		      lstVideos.CellValueAt(row, 2) = New WebListBoxStyleRenderer(centeredStyle, orderValue)
		      
		      ' Store video_id in rowtag
		      lstVideos.RowTagAt(lstVideos.LastAddedRowIndex) = rs.Column("video_id").IntegerValue
		      
		      rs.MoveToNextRow
		    Wend
		    
		    ' Select first row and manually load video
		    If lstVideos.RowCount > 0 Then
		      lstVideos.SelectedRowIndex = 0
		      ' Manually trigger video load since SelectionChanged doesn't fire programmatically
		      LoadVideoPreview(0)
		    End If
		    
		  Catch e As DatabaseException
		    MessageBox("Error loading videos: " + e.Message)
		  End Try
		End Sub
	#tag EndMethod

	#tag Method, Flags = &h21
		Private Sub LoadVideoPreview(rowIndex As Integer)
		  If rowIndex < 0 Then
		    htmlVideoPreview.LoadHTML("")
		    Return
		  End If
		  
		  Var videoFilename As String = lstVideos.CellTextAt(rowIndex, 0)
		  Var wf As WebFile = Session.ServeVideo(videoFilename)
		  
		  If wf = Nil Then
		    Var errorHTML As String = "<!DOCTYPE html><html><head><meta charset='UTF-8'><style>"
		    errorHTML = errorHTML + "body{margin:0;padding:20px;background:#f5f5f5;color:#e74c3c;font-family:Arial,sans-serif;}"
		    errorHTML = errorHTML + ".error{background:#fff;padding:20px;border-radius:8px;border-left:4px solid #e74c3c;}"
		    errorHTML = errorHTML + "</style></head><body><div class='error'>"
		    errorHTML = errorHTML + "<h3>⚠️ Video Not Found</h3>"
		    errorHTML = errorHTML + "<p>The video file <strong>" + videoFilename + "</strong> could not be loaded.</p>"
		    errorHTML = errorHTML + "</div></body></html>"
		    
		    htmlVideoPreview.LoadHTML(errorHTML)
		    Return
		  End If
		  
		  Var videoURL As String = wf.URL
		  System.DebugLog("Loading video in preview: " + videoURL)
		  
		  ' HTML with max-width and max-height constraints
		  Var html As String = "<!DOCTYPE html><html><head><meta charset='UTF-8'>"
		  html = html + "<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
		  html = html + "<style>"
		  html = html + "* { margin: 0; padding: 0; box-sizing: border-box; }"
		  html = html + "html, body { height: 100%; width: 100%; overflow: hidden; background: #f5f5f5; }"
		  
		  ' Wrapper centers the video
		  html = html + ".video-wrapper { display: flex; align-items: center; justify-content: center; height: 100%; width: 100%; padding: 10px; }"
		  
		  ' Container with max dimensions and 4:3 aspect ratio
		  html = html + ".video-container { position: relative; width: 100%; max-width: 495px; max-height: 373px; aspect-ratio: 4 / 3; background: #000; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.15); }"
		  
		  ' Video fills container
		  html = html + "video { width: 100%; height: 100%; display: block; background: #000; object-fit: contain; }"
		  
		  html = html + ".info { position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); color: #fff; font-size: 11px; background: rgba(0,0,0,0.7); padding: 4px 8px; border-radius: 4px; white-space: nowrap; z-index: 10; }"
		  
		  html = html + "</style></head><body>"
		  html = html + "<div class='video-wrapper'>"
		  html = html + "<div class='video-container'>"
		  html = html + "<video controls loop autoplay playsinline>"
		  html = html + "<source src='" + videoURL + "' type='video/mp4'>"
		  html = html + "Your browser does not support video.</video>"
		  html = html + "<div class='info'>" + videoFilename + "</div>"
		  html = html + "</div></div>"
		  html = html + "</body></html>"
		  
		  htmlVideoPreview.LoadHTML(html)
		End Sub
	#tag EndMethod

	#tag Method, Flags = &h0
		Sub TrackAnswerChange()
		  ' ******************************************************************
		  ' Track changes to answers
		  ' ******************************************************************
		  mAnswersChanged = True
		End Sub
	#tag EndMethod

	#tag Method, Flags = &h0
		Sub TrackCaseInfoChange()
		  ' ******************************************************************
		  ' Track changes to case info
		  ' ******************************************************************
		  mCaseInfoChanged = True
		End Sub
	#tag EndMethod


	#tag Property, Flags = &h0
		CaseID As Integer
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mAnswersChanged As Boolean = False
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mCaseInfoChanged As Boolean = False
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mGroupsChanged As Boolean = False
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mLastColumn As Integer
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mLastNewValue As String
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mLastOldValue As String
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mLastVideoID As integer
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mOriginalCellValue As String
	#tag EndProperty

	#tag Property, Flags = &h21
		Private mOriginalGroups() As String
	#tag EndProperty


#tag EndWindowCode

#tag Events lstVideos
	#tag Event
		Sub SelectionChanged(rows() As Integer)
		  ' ******************************************************************
		  ' lstVideos.SelectionChanged Event (WITH WEBFILE AND PURPOSE)
		  ' ******************************************************************
		  #Pragma Unused rows
		  
		  LoadVideoPreview(Me.SelectedRowIndex)
		End Sub
	#tag EndEvent
	#tag Event
		Sub CellAction(row As Integer, column As Integer, value As Variant)
		  ' ******************************************************************
		  ' lstVideos.CellAction Event - Handle inline editing
		  ' ******************************************************************
		  System.DebugLog("CellAction fired - Row: " + Str(row) + ", Column: " + Str(column) + ", Value: " + value.StringValue)
		  
		  If column >= 1 And column <= 2 Then
		    Var videoID As Integer = Me.RowTagAt(row)
		    Var newValue As String = value.StringValue.Trim
		    
		    ' Get old value from database for undo functionality
		    Var oldValue As String = ""
		    Var getOldSQL As String
		    Select Case column
		    Case 1
		      getOldSQL = "SELECT view_description FROM case_videos WHERE video_id = ?"
		    Case 2
		      getOldSQL = "SELECT video_order FROM case_videos WHERE video_id = ?"
		    Else
		      Return
		    End Select
		    
		    Try
		      Var getOldPS As MySQLPreparedStatement = Session.DB.Prepare(getOldSQL)
		      getOldPS.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		      getOldPS.Bind(0, videoID)
		      Var oldRS As RowSet = getOldPS.SelectSQL
		      
		      If oldRS <> Nil And Not oldRS.AfterLastRow Then
		        If column = 1 Then
		          oldValue = oldRS.Column("view_description").StringValue
		        Else
		          oldValue = Str(oldRS.Column("video_order").IntegerValue)
		        End If
		      End If
		    Catch e As DatabaseException
		      System.DebugLog("Error getting old value: " + e.Message)
		    End Try
		    
		    ' Store for undo functionality
		    mLastVideoID = videoID
		    mLastColumn = column
		    mLastOldValue = oldValue
		    mLastNewValue = newValue
		    
		    System.DebugLog("Old value from DB: '" + oldValue + "', New value: '" + newValue + "'")
		    
		    ' Update the database
		    Var sql As String
		    Select Case column
		    Case 1
		      sql = "UPDATE case_videos SET view_description = ? WHERE video_id = ?"
		    Case 2
		      sql = "UPDATE case_videos SET video_order = ? WHERE video_id = ?"
		    Else
		      Return
		    End Select
		    
		    Try
		      Var ps As MySQLPreparedStatement = Session.DB.Prepare(sql)
		      
		      If column = 2 Then
		        ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		        Var orderValue As Integer = Val(newValue)
		        If orderValue < 0 Then orderValue = 0
		        ps.Bind(0, orderValue)
		      Else
		        ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		        ps.Bind(0, newValue)
		      End If
		      
		      ps.BindType(1, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		      ps.Bind(1, videoID)
		      
		      ps.ExecuteSQL
		      
		      System.DebugLog("Video metadata updated in database: video_id=" + Str(videoID) + ", new value: '" + newValue + "'")
		      btnUndoVideoEdit.Enabled = True
		      
		      ' If order was changed, reload to re-sort
		      If column = 2 Then
		        System.DebugLog("Reloading videos to re-sort by order")
		        LoadCaseVideos()
		      End If
		      
		    Catch e As DatabaseException
		      MessageBox("Error updating video: " + e.Message)
		      System.DebugLog("Database error: " + e.Message)
		    End Try
		  End If
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events txtCaseLabel
	#tag Event
		Sub TextChanged()
		  TrackCaseInfoChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkPericardialEffusion
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkIVCHighPressure
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkRequiresFullEcho
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events txtCorrectConclusions
	#tag Event
		Sub TextChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events btnStartUpload
	#tag Event
		Sub Pressed()
		  ' ******************************************************************
		  ' btnStartUpload.Pressed Event
		  ' ******************************************************************
		  uplVideo.StartUpload
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events btnDeleteVideo
	#tag Event
		Sub Pressed()
		  ' ******************************************************************
		  ' btnDeleteVideo.Pressed Event
		  ' ******************************************************************
		  If lstVideos.SelectedRowIndex < 0 Then
		    MessageBox("Please select a video to delete")
		    Return
		  End If
		  
		  Var d As New WebMessageDialog
		  d.Title = "Confirm Delete"
		  d.Message = "Are you sure you want to delete this video? This action cannot be undone."
		  d.ActionButton.Caption = "Delete"
		  d.CancelButton.Caption = "Cancel"
		  d.CancelButton.Visible = True
		  
		  AddHandler d.ButtonPressed, AddressOf HandleDeleteVideoConfirm
		  d.Show
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events btnSaveAll
	#tag Event
		Sub Pressed()
		  ' ******************************************************************
		  ' btnSaveAll.Pressed Event
		  ' ******************************************************************
		  ' Check if anything has changed
		  If Not mCaseInfoChanged And Not mAnswersChanged And Not mGroupsChanged Then
		    MessageBox("No changes to save.")
		    Return
		  End If
		  
		  ' Validate case label
		  If txtCaseLabel.Text.Trim = "" Then
		    MessageBox("Case description cannot be empty")
		    Return
		  End If
		  
		  Try
		    Session.DB.BeginTransaction
		    Var changesMade As Boolean = False
		    
		    ' Save case info (description) and groups if changed
		    If mCaseInfoChanged Or mGroupsChanged Then
		      Var sqlCase As String = "UPDATE cases SET case_label = ?, case_groups = ? WHERE case_id = ?"
		      Var psCase As MySQLPreparedStatement = Session.DB.Prepare(sqlCase)
		      psCase.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		      psCase.Bind(0, txtCaseLabel.Text.Trim)
		      psCase.BindType(1, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		      psCase.Bind(1, GetCurrentGroups())
		      psCase.BindType(2, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		      psCase.Bind(2, CaseID)
		      psCase.ExecuteSQL
		      changesMade = True
		      mCaseInfoChanged = False
		      mGroupsChanged = False
		    End If
		    
		    ' Save correct answers if changed (FIXED: uses MYSQL_TYPE_NULL)
		    If mAnswersChanged Then
		      Var sqlAnswers As String = "UPDATE cases SET "
		      sqlAnswers = sqlAnswers + "lv_size_dilated=?, lv_function_impaired=?, rv_size_dilated=?, rv_function_impaired=?, "
		      sqlAnswers = sqlAnswers + "aortic_stenosis_significant=?, aortic_regurgitation_significant=?, "
		      sqlAnswers = sqlAnswers + "mitral_stenosis_significant=?, mitral_regurgitation_significant=?, "
		      sqlAnswers = sqlAnswers + "tricuspid_stenosis_significant=?, tricuspid_regurgitation_significant=?, "
		      sqlAnswers = sqlAnswers + "pericardial_effusion_significant=?, ivc_high_ra_pressure=?, "
		      sqlAnswers = sqlAnswers + "correct_conclusions=?, requires_full_echo=? "
		      sqlAnswers = sqlAnswers + "WHERE case_id=?"
		      
		      Var psAnswers As MySQLPreparedStatement = Session.DB.Prepare(sqlAnswers)
		      
		      ' Bind all 12 finding checkboxes with NULL support (FIXED)
		      If chkLVSizeDilated.Indeterminate Then
		        psAnswers.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(0, Nil)
		      Else
		        psAnswers.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(0, chkLVSizeDilated.Value)
		      End If
		      
		      If chkLVFunctionImpaired.Indeterminate Then
		        psAnswers.BindType(1, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(1, Nil)
		      Else
		        psAnswers.BindType(1, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(1, chkLVFunctionImpaired.Value)
		      End If
		      
		      If chkRVSizeDilated.Indeterminate Then
		        psAnswers.BindType(2, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(2, Nil)
		      Else
		        psAnswers.BindType(2, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(2, chkRVSizeDilated.Value)
		      End If
		      
		      If chkRVFunctionImpaired.Indeterminate Then
		        psAnswers.BindType(3, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(3, Nil)
		      Else
		        psAnswers.BindType(3, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(3, chkRVFunctionImpaired.Value)
		      End If
		      
		      If chkAorticStenosis.Indeterminate Then
		        psAnswers.BindType(4, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(4, Nil)
		      Else
		        psAnswers.BindType(4, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(4, chkAorticStenosis.Value)
		      End If
		      
		      If chkAorticRegurgitation.Indeterminate Then
		        psAnswers.BindType(5, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(5, Nil)
		      Else
		        psAnswers.BindType(5, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(5, chkAorticRegurgitation.Value)
		      End If
		      
		      If chkMitralStenosis.Indeterminate Then
		        psAnswers.BindType(6, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(6, Nil)
		      Else
		        psAnswers.BindType(6, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(6, chkMitralStenosis.Value)
		      End If
		      
		      If chkMitralRegurgitation.Indeterminate Then
		        psAnswers.BindType(7, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(7, Nil)
		      Else
		        psAnswers.BindType(7, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(7, chkMitralRegurgitation.Value)
		      End If
		      
		      If chkTricuspidStenosis.Indeterminate Then
		        psAnswers.BindType(8, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(8, Nil)
		      Else
		        psAnswers.BindType(8, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(8, chkTricuspidStenosis.Value)
		      End If
		      
		      If chkTricuspidRegurgitation.Indeterminate Then
		        psAnswers.BindType(9, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(9, Nil)
		      Else
		        psAnswers.BindType(9, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(9, chkTricuspidRegurgitation.Value)
		      End If
		      
		      If chkPericardialEffusion.Indeterminate Then
		        psAnswers.BindType(10, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(10, Nil)
		      Else
		        psAnswers.BindType(10, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(10, chkPericardialEffusion.Value)
		      End If
		      
		      If chkIVCHighPressure.Indeterminate Then
		        psAnswers.BindType(11, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(11, Nil)
		      Else
		        psAnswers.BindType(11, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(11, chkIVCHighPressure.Value)
		      End If
		      
		      ' Bind correct conclusions text
		      psAnswers.BindType(12, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		      psAnswers.Bind(12, txtCorrectConclusions.Text)
		      
		      ' Bind requires_full_echo checkbox (13th checkbox)
		      If chkRequiresFullEcho.Indeterminate Then
		        psAnswers.BindType(13, MySQLPreparedStatement.MYSQL_TYPE_NULL)
		        psAnswers.Bind(13, Nil)
		      Else
		        psAnswers.BindType(13, MySQLPreparedStatement.MYSQL_TYPE_TINY)
		        psAnswers.Bind(13, chkRequiresFullEcho.Value)
		      End If
		      
		      ' Bind WHERE clause case_id
		      psAnswers.BindType(14, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		      psAnswers.Bind(14, CaseID)
		      
		      psAnswers.ExecuteSQL
		      changesMade = True
		      mAnswersChanged = False
		    End If
		    
		    Session.DB.CommitTransaction
		    
		    If changesMade Then
		      MessageBox("All changes saved successfully!")
		      
		      ' Update original groups tracking
		      mOriginalGroups.RemoveAll
		      For i As Integer = 0 To lstAssignedGroups.RowCount - 1
		        mOriginalGroups.Add(lstAssignedGroups.CellTextAt(i, 0))
		      Next
		    End If
		    
		  Catch e As DatabaseException
		    Session.DB.RollbackTransaction
		    MessageBox("Error saving changes: " + e.Message)
		  End Try
		  
		  ' =============================================================================
		  ' Notes:
		  ' * FIXED: Uses MYSQL_TYPE_NULL when binding Nil for indeterminate checkboxes
		  ' * Uses MYSQL_TYPE_TINY when binding actual boolean values
		  ' * All 13 checkboxes properly handle indeterminate state
		  ' =============================================================================
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events btnCancelChanges
	#tag Event
		Sub Pressed()
		  ' ******************************************************************
		  ' btnCancelChanges.Pressed Event
		  ' ******************************************************************
		  ' Reload original values
		  LoadCaseDetails
		  mCaseInfoChanged = False
		  mAnswersChanged = False
		  mGroupsChanged = False
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events uplVideo
	#tag Event
		Sub FileAdded(filename As String, bytes As UInt64, mimeType As String)
		  ' ******************************************************************
		  ' uplVideo.FileAdded Event
		  ' ******************************************************************
		  ' Enable upload button when file is selected
		  btnStartUpload.Enabled = True
		  System.DebugLog("File selected: " + filename + " (" + Str(bytes) + " bytes)")
		  
		End Sub
	#tag EndEvent
	#tag Event
		Sub FileRemoved(filename As String)
		  ' ******************************************************************
		  ' uplVideo.FileRemoved Event
		  ' ******************************************************************
		  ' Disable upload button when file is removed
		  btnStartUpload.Enabled = False
		  System.DebugLog("File removed: " + filename)
		End Sub
	#tag EndEvent
	#tag Event
		Sub UploadError(error As RuntimeException)
		  ' ******************************************************************
		  ' uplVideo.UploadError Event
		  ' ******************************************************************
		  MessageBox("Upload error: " + error.Message)
		  btnStartUpload.Enabled = True  ' Re-enable for retry
		End Sub
	#tag EndEvent
	#tag Event
		Sub UploadFinished(files() As WebUploadedFile)
		  ' ******************************************************************
		  ' uplVideo.UploadFinished Event
		  '    Get the first (and only, since AllowMultipleFiles = False) file
		  ' ******************************************************************
		  Var uploadedFile As WebUploadedFile = files(0)
		  
		  Try
		    ' Get or create the CaseVideos folder
		    Var targetFolder As FolderItem = SpecialFolder.Documents.Child("CaseVideos")
		    If Not targetFolder.Exists Then
		      targetFolder.CreateFolder
		      System.DebugLog("Created CaseVideos folder: " + targetFolder.NativePath)
		    End If
		    
		    System.DebugLog("Target folder: " + targetFolder.NativePath)
		    
		    ' Create the target file
		    Var targetFile As FolderItem = targetFolder.Child(uploadedFile.Name)
		    
		    ' If file already exists, delete it first
		    If targetFile.Exists Then
		      System.DebugLog("File already exists, deleting: " + targetFile.NativePath)
		      Try
		        targetFile.Remove
		      Catch deleteError As IOException
		        MessageBox("Error: Cannot overwrite existing file. " + deleteError.Message)
		        Return
		      End Try
		    End If
		    
		    System.DebugLog("Writing file: " + targetFile.NativePath)
		    
		    ' Create and write to the file
		    Var outputStream As BinaryStream = BinaryStream.Create(targetFile, True)
		    If outputStream = Nil Then
		      MessageBox("Error: Could not create output stream for " + uploadedFile.Name)
		      Return
		    End If
		    
		    outputStream.Write(uploadedFile.Data)
		    outputStream.Close
		    
		    System.DebugLog("Video saved successfully: " + targetFile.NativePath)
		    
		    ' Get next order number
		    Var orderSQL As String = "SELECT COALESCE(MAX(video_order), -1) + 1 AS next_order FROM case_videos WHERE case_id = ?"
		    Var orderPS As MySQLPreparedStatement = Session.DB.Prepare(orderSQL)
		    orderPS.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		    orderPS.Bind(0, CaseID)
		    Var orderRS As RowSet = orderPS.SelectSQL
		    Var videoOrder As Integer = 0
		    If orderRS <> Nil And Not orderRS.AfterLastRow Then
		      videoOrder = orderRS.Column("next_order").IntegerValue
		    End If
		    
		    ' Insert into database (video_purpose can be empty or used for other purposes)
		    Var sql As String = "INSERT INTO case_videos (case_id, video_filename, view_description, video_purpose, video_order) VALUES (?, ?, ?, ?, ?)"
		    Var ps As MySQLPreparedStatement = Session.DB.Prepare(sql)
		    ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		    ps.BindType(1, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		    ps.BindType(2, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		    ps.BindType(3, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		    ps.BindType(4, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		    
		    ps.Bind(0, CaseID)
		    ps.Bind(1, uploadedFile.Name)
		    ps.Bind(2, "")
		    ps.Bind(3, "")  ' video_purpose left empty (reserved for future use)
		    ps.Bind(4, videoOrder)
		    
		    ps.ExecuteSQL
		    
		    MessageBox("Video uploaded successfully!")
		    LoadCaseVideos
		    
		    uplVideo.RemoveAllFiles
		    btnStartUpload.Enabled = False
		    
		  Catch e As IOException
		    System.DebugLog("IOException: " + e.Message)
		    MessageBox("Error saving video file: " + e.Message + EndOfLine + EndOfLine + _
		    "This may be a permissions issue. Check the console for details.")
		  Catch e As DatabaseException
		    MessageBox("Error saving video to database: " + e.Message)
		  End Try
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events btnAddGroup
	#tag Event
		Sub Pressed()
		  ' ******************************************************************
		  ' btnAddGroup.Pressed Event
		  ' ******************************************************************
		  If popAvailableGroups.SelectedRowIndex < 0 Then
		    MessageBox("Please select a group to add")
		    Return
		  End If
		  
		  Var selectedGroup As String = popAvailableGroups.RowTextAt(popAvailableGroups.SelectedRowIndex)
		  
		  ' Check if already assigned
		  For i As Integer = 0 To lstAssignedGroups.RowCount - 1
		    If lstAssignedGroups.CellTextAt(i, 0) = selectedGroup Then
		      MessageBox("This group is already assigned")
		      Return
		    End If
		  Next
		  
		  ' Add to list
		  lstAssignedGroups.AddRow(selectedGroup)
		  mGroupsChanged = True
		  
		  TrackCaseInfoChange
		  System.DebugLog("Group added: " + selectedGroup)
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events lstAssignedGroups
	#tag Event
		Sub SelectionChanged(rows() As Integer)
		  
		End Sub
	#tag EndEvent
	#tag Event
		Sub CellAction(row As Integer, column As Integer, value As Variant)
		  ' ******************************************************************
		  ' lstVideos.CellAction Event - Handle inline editing
		  ' ******************************************************************
		  If column >= 1 And column <= 3 Then
		    ' Store original value before editing
		    mOriginalCellValue = Me.CellTextAt(row, column)
		    
		    ' Get the new value from the edit
		    Var newValue As String = value.StringValue
		    
		    ' If value actually changed, save it
		    If newValue <> mOriginalCellValue Then
		      Var videoID As Integer = Me.RowTagAt(row)
		      
		      ' Store for undo
		      mLastVideoID = videoID
		      mLastColumn = column
		      mLastOldValue = mOriginalCellValue
		      mLastNewValue = newValue
		      
		      ' Update the cell display
		      Me.CellTextAt(row, column) = newValue
		      
		      ' Save to database
		      Var sql As String
		      Select Case column
		      Case 1
		        sql = "UPDATE case_videos SET view_description = ? WHERE video_id = ?"
		      Case 2
		        sql = "UPDATE case_videos SET video_purpose = ? WHERE video_id = ?"
		      Case 3
		        sql = "UPDATE case_videos SET video_order = ? WHERE video_id = ?"
		      Else
		        Return
		      End Select
		      
		      Try
		        Var ps As MySQLPreparedStatement = Session.DB.Prepare(sql)
		        
		        If column = 3 Then
		          ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		          Var orderValue As Integer = Val(newValue)
		          If orderValue < 0 Then orderValue = 0
		          ps.Bind(0, orderValue)
		        Else
		          ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		          ps.Bind(0, newValue)
		        End If
		        
		        ps.BindType(1, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		        ps.Bind(1, videoID)
		        
		        ps.ExecuteSQL
		        
		        System.DebugLog("Video metadata updated: video_id=" + Str(videoID))
		        btnUndoVideoEdit.Enabled = True
		        
		      Catch e As DatabaseException
		        MessageBox("Error updating video: " + e.Message)
		        Me.CellTextAt(row, column) = mOriginalCellValue
		      End Try
		    End If
		  End If
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events btnRemoveGroup
	#tag Event
		Sub Pressed()
		  ' ******************************************************************
		  ' btnRemoveGroup.Pressed Event
		  ' ******************************************************************
		  If lstAssignedGroups.SelectedRowIndex < 0 Then
		    MessageBox("Please select a group to remove")
		    Return
		  End If
		  
		  Var selectedGroup As String = lstAssignedGroups.CellTextAt(lstAssignedGroups.SelectedRowIndex, 0)
		  lstAssignedGroups.RemoveRowAt(lstAssignedGroups.SelectedRowIndex)
		  mGroupsChanged = True
		  
		  TrackCaseInfoChange
		  System.DebugLog("Group removed: " + selectedGroup)
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkLVSizeDilated
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkLVFunctionImpaired
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkRVSizeDilated
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkRVFunctionImpaired
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkAorticStenosis
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkAorticRegurgitation
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkMitralStenosis
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkMitralRegurgitation
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkTricuspidStenosis
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events chkTricuspidRegurgitation
	#tag Event
		Sub ValueChanged()
		  TrackAnswerChange
		End Sub
	#tag EndEvent
#tag EndEvents
#tag Events btnUndoVideoEdit
	#tag Event
		Sub Pressed()
		  '******************************************************************
		  ' btnUndoVideoEdit.Pressed Event
		  ' ******************************************************************
		  If mLastVideoID = 0 Then
		    MessageBox("No change to undo")
		    Return
		  End If
		  
		  Var sql As String
		  Select Case mLastColumn
		  Case 1
		    sql = "UPDATE case_videos SET view_description = ? WHERE video_id = ?"
		  Case 2
		    sql = "UPDATE case_videos SET video_order = ? WHERE video_id = ?"
		  Else
		    Return
		  End Select
		  
		  Try
		    Var ps As MySQLPreparedStatement = Session.DB.Prepare(sql)
		    
		    If mLastColumn = 2 Then
		      ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		      Var orderValue As Integer = Val(mLastOldValue)
		      If orderValue < 0 Then orderValue = 0
		      ps.Bind(0, orderValue)
		    Else
		      ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_STRING)
		      ps.Bind(0, mLastOldValue)
		    End If
		    
		    ps.BindType(1, MySQLPreparedStatement.MYSQL_TYPE_LONG)
		    ps.Bind(1, mLastVideoID)
		    
		    ps.ExecuteSQL
		    
		    System.DebugLog("Video metadata change undone: video_id=" + Str(mLastVideoID) + ", restored to: '" + mLastOldValue + "'")
		    
		    ' Always reload to refresh the display (especially important for order changes)
		    LoadCaseVideos()
		    
		    btnUndoVideoEdit.Enabled = False
		    mLastVideoID = 0
		    mLastColumn = 0
		    mLastOldValue = ""
		    mLastNewValue = ""
		    
		  Catch e As DatabaseException
		    MessageBox("Error undoing change: " + e.Message)
		  End Try
		End Sub
	#tag EndEvent
#tag EndEvents
#tag ViewBehavior
	#tag ViewProperty
		Name="EnableBackButton"
		Visible=false
		Group="Behavior"
		InitialValue="True"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="EnableLogoutButton"
		Visible=false
		Group="Behavior"
		InitialValue="True"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="Name"
		Visible=true
		Group="ID"
		InitialValue=""
		Type="String"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="Super"
		Visible=true
		Group="ID"
		InitialValue=""
		Type="String"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="Left"
		Visible=true
		Group="Position"
		InitialValue="0"
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="Top"
		Visible=true
		Group="Position"
		InitialValue="0"
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="Enabled"
		Visible=true
		Group="Behavior"
		InitialValue="True"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="LockBottom"
		Visible=true
		Group="Behavior"
		InitialValue="False"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="LockHorizontal"
		Visible=true
		Group="Behavior"
		InitialValue="False"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="LockLeft"
		Visible=true
		Group="Behavior"
		InitialValue="True"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="LockRight"
		Visible=true
		Group="Behavior"
		InitialValue="False"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="LockTop"
		Visible=true
		Group="Behavior"
		InitialValue="True"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="LockVertical"
		Visible=true
		Group="Behavior"
		InitialValue="False"
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="Visible"
		Visible=true
		Group="Behavior"
		InitialValue=""
		Type="Boolean"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="ScrollDirection"
		Visible=true
		Group="Behavior"
		InitialValue="ScrollDirections.None"
		Type="WebContainer.ScrollDirections"
		EditorType="Enum"
		#tag EnumValues
			"0 - None"
			"1 - Horizontal"
			"2 - Vertical"
			"3 - Both"
		#tag EndEnumValues
	#tag EndViewProperty
	#tag ViewProperty
		Name="TabIndex"
		Visible=true
		Group="Visual Controls"
		InitialValue=""
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="LayoutType"
		Visible=true
		Group="View"
		InitialValue="LayoutTypes.Fixed"
		Type="LayoutTypes"
		EditorType="Enum"
		#tag EnumValues
			"0 - Fixed"
			"1 - Flex"
		#tag EndEnumValues
	#tag EndViewProperty
	#tag ViewProperty
		Name="LayoutDirection"
		Visible=true
		Group="View"
		InitialValue="LayoutDirections.LeftToRight"
		Type="LayoutDirections"
		EditorType="Enum"
		#tag EnumValues
			"0 - LeftToRight"
			"1 - RightToLeft"
			"2 - TopToBottom"
			"3 - BottomToTop"
		#tag EndEnumValues
	#tag EndViewProperty
	#tag ViewProperty
		Name="PanelIndex"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="_mPanelIndex"
		Visible=false
		Group="Behavior"
		InitialValue="-1"
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="ControlCount"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="ControlID"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="String"
		EditorType="MultiLineEditor"
	#tag EndViewProperty
	#tag ViewProperty
		Name="_mDesignHeight"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="_mDesignWidth"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="_mName"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="String"
		EditorType="MultiLineEditor"
	#tag EndViewProperty
	#tag ViewProperty
		Name="Indicator"
		Visible=false
		Group="Visual Controls"
		InitialValue=""
		Type="WebUIControl.Indicators"
		EditorType="Enum"
		#tag EnumValues
			"0 - Default"
			"1 - Primary"
			"2 - Secondary"
			"3 - Success"
			"4 - Danger"
			"5 - Warning"
			"6 - Info"
			"7 - Light"
			"8 - Dark"
			"9 - Link"
		#tag EndEnumValues
	#tag EndViewProperty
	#tag ViewProperty
		Name="ContainerID"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="String"
		EditorType="MultiLineEditor"
	#tag EndViewProperty
	#tag ViewProperty
		Name="Position"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="PositionEnum"
		EditorType="Enum"
		#tag EnumValues
			"0 - Center"
			"1 - TopLeft"
		#tag EndEnumValues
	#tag EndViewProperty
	#tag ViewProperty
		Name="Width"
		Visible=false
		Group=""
		InitialValue="250"
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="Height"
		Visible=false
		Group=""
		InitialValue="250"
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
	#tag ViewProperty
		Name="CaseID"
		Visible=false
		Group="Behavior"
		InitialValue=""
		Type="Integer"
		EditorType=""
	#tag EndViewProperty
#tag EndViewBehavior
