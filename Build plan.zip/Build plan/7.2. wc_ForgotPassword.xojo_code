' 1. Insert → WebContainer
' 2. Name: **wc_ForgotPassword**
' 3. Super: **wc_Base**

' *******************************************************************************
' Controls:
' *******************************************************************************
' - Label: `lblTitle` (text: "Forgot Password", Bold)
' - Label: `lblInstructions` (text: "Enter your email address to receive a password reset code")
' - Label: `lblEmail` (text: "Email Address:")
' - TextField: `txtEmail`
' - PushButton: `btnSendCode` (text: "Send Reset Code")
' - PushButton: `btnBackToLogin` (text: "Back to Login")
' - Label: `lblMessage` (text: "", Visible = False)

' *******************************************************************************
' wc_ForgotPassword.Opening event
' *******************************************************************************
Sub Opening()
  lblMessage.Text = ""
  lblMessage.Visible = False
End Sub

' *******************************************************************************
' Methods
' *******************************************************************************
Sub ShowMessage(msg As String, isSuccess As Boolean)
  lblMessage.Text = msg
  lblMessage.TextColor = If(isSuccess, &c27ae60, &ce74c3c)
  lblMessage.Visible = True
End Sub

Function ValidateEmail(email As String) As Boolean
  If email.IndexOf("@") < 1 Then Return False
  If email.IndexOf(".") < 3 Then Return False
  If email.Length < 5 Then Return False
  Return True
End Function

Sub NavigateToOTPEntry(t As Timer)
  Var otpEntry As New wc_EnterOTP
  otpEntry.ContainerID = "EnterOTP"
  otpEntry.Position = wc_Base.PositionEnum.Center
  otpEntry.UserEmail = txtEmail.Text.Trim
  Session.Navigation.NavigateTo(otpEntry)
End Sub


' *******************************************************************************
' btnSendCode.Pressed Event
' *******************************************************************************   
Sub Pressed()
  If txtEmail.Text.Trim = "" Then
    ShowMessage("Please enter your email address", False)
    Return
  End If
  
  If Not ValidateEmail(txtEmail.Text.Trim) Then
    ShowMessage("Please enter a valid email address", False)
    Return
  End If
  
  Var sql As String = "SELECT user_id, full_name, email FROM users WHERE email = ?"
  
  Try
    Var ps As MySQLPreparedStatement = Session.DB.Prepare(sql)
    ps.BindType(0, MySQLPreparedStatement.MYSQL_TYPE_STRING)
    ps.Bind(0, txtEmail.Text.Trim)
    
    Var rs As RowSet = ps.SQLSelect
    
    If rs = Nil Or rs.AfterLastRow Then
      ShowMessage("If this email is registered, you will receive a password reset code shortly.", True)
      Return
    End If
    
    Var userID As Integer = rs.Column("user_id").IntegerValue
    Var userName As String = rs.Column("full_name").StringValue
    Var userEmail As String = rs.Column("email").StringValue
    
    Var ipAddress As String = "unknown"
    
    Var tokenResult As Dictionary = PasswordResetHelper.CreatePasswordResetToken(userID, ipAddress)
    
    If Not tokenResult.Value("success") Then
      ShowMessage("An error occurred. Please try again later.", False)
      Return
    End If
    
    Var otp As String = tokenResult.Value("otp")
    Var token As String = tokenResult.Value("token")
    
    Var resetLink As String = "https://your-domain.com/reset/" + token
    
    If EmailHelper.SendPasswordResetEmail(userEmail, userName, otp, resetLink) Then
      ShowMessage("A password reset code has been sent to your email.", True)
      
      Var t As New Timer
      t.Period = 2000
      t.Mode = Timer.ModeOff
      AddHandler t.Action, AddressOf NavigateToOTPEntry
      t.RunMode = Timer.RunModes.Single
      t.Enabled = True
      
    Else
      ShowMessage("Failed to send email. Please try again later.", False)
    End If
    
  Catch e As DatabaseException
    ShowMessage("An error occurred: " + e.Message, False)
  End Try
End Sub


' *******************************************************************************
' btnBackToLogin.Pressed Event
' *******************************************************************************
Sub Pressed()
  Session.Navigation.NavigateBack
End Sub